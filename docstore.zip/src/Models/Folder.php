<?php

namespace LaurentMeuwly\Docstore\Models;

use Illuminate\Database\Eloquent\Builder;
use Illuminate\Database\Eloquent\Collection;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsTo;
use Illuminate\Database\Eloquent\Relations\HasMany;

/**
 * @property int $id
 * @property int|null $parent_id
 * @property string $name
 * @property int|null $position
 * @property-read Folder|null $parent
 * @property-read Collection<int, Folder> $children
 * @property-read Collection<int, Document> $documents
 */
class Folder extends Model
{
    protected $fillable = [
        'parent_id',
        'name',
        'position',
    ];

    protected $casts = [
        'parent_id' => 'integer',
        'position' => 'integer',
    ];

    public static function model(): string
    {
        return config('docstore.models.folder', self::class);
    }

    public function parent(): BelongsTo
    {
        $model = static::model();

        return $this->belongsTo($model, 'parent_id');
    }

    public function children(): HasMany
    {
        $model = static::model();

        return $this->hasMany($model, 'parent_id')
            ->orderBy('position')
            ->orderBy('id');
    }

    /**
     * @return HasMany<Document, self>
     */
    public function documents(): HasMany
    {
        return $this->hasMany(config('docstore.models.document'));
    }

    public function getFullPathAttribute(): string
    {
        if (! $this->parent) {
            return $this->name;
        }

        return $this->parent->full_path.' / '.$this->name;
    }

    /**
     * @param  Builder<self>  $query
     * @return Builder<self>
     */
    public function scopeRoot(Builder $query): Builder
    {
        return $query->whereNull('parent_id');
    }
}
